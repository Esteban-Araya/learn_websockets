
function mensajeAdmin() {
    const mensaje = document.getElementById("mensajeAdmin");
    mensaje.textContent = data.message
    console.log("in the")
}

